package main

import (
	"log"

	"github.com/gofiber/fiber"
	"github.com/josh114/fiberapi/database"
	"github.com/josh114/fiberapi/router"
)





func main (){
	database.ConnectDb()
	app := fiber.New()
	router.SetupRoutes(app)
	// SetupRoutes(app)
	log.Fatal(app.Listen(":9000"))
} 