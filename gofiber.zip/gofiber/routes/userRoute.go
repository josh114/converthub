package routes

import (
	"errors"
	"log"
	"strconv"

	"github.com/gofiber/fiber"
	"github.com/josh114/fiberapi/database"
	"github.com/josh114/fiberapi/models"
)


type User struct {
	ID uint `json:"id"`
	FirstName string `josn:"first_name"`
	LastName string `josn:"last_name"`
 	
}

func CreateResponseUser(userModel models.User) User {
	return User{ID: userModel.ID, FirstName: userModel.FirstName, LastName: userModel.LastName }
}

func CreateUser(c *fiber.Ctx)  {
	var user models.User

	if err := c.BodyParser(&user); err != nil {
	 c.Status(400).JSON(err.Error())
	 return
	}
	log.Println("this is user data", &user)
	database.Database.Db.Create(&user)
	responseUser := CreateResponseUser(user)
	c.Status(200).JSON(responseUser )
}

func GetUsers(c *fiber.Ctx) {
	users := []models.User{}
	database.Database.Db.Find(&users)
	responseUsers := []User{}

	for _, user := range users {
		responseUser := CreateResponseUser(user)
		responseUsers = append(responseUsers, responseUser)
		
	}
	c.Status(200).JSON(responseUsers) 
}
func findUser(id int, user *models.User) error {
	database.Database.Db.Find(&user, "id = ?", id)
	if user.ID == 0 {
		return errors.New("user does not exist")
	}
	return nil
}
func GetUser(c *fiber.Ctx) {
	idStr := c.Params("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.Status(400).JSON("Please ensure that :id is an integer")
		return
	}
	var user models.User
	if err := findUser(id, &user); err != nil {
		c.Status(400).JSON(err.Error())
		return
	}
	responseUser := CreateResponseUser(user)
	c.Status(200).JSON(responseUser)
}
func UpdateUser(c *fiber.Ctx) {
	idStr := c.Params("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.Status(400).JSON("Please ensure that :id is an integer")
		return
	}
	var user models.User
	if err := findUser(id, &user); err != nil {
		c.Status(400).JSON(err.Error())
		return
	}
	type UpdateUser struct {
		FirstName string `json:"first_name"`
		LastName string `json:"last_name"`
	}
	var updateData UpdateUser
	if err := c.BodyParser(&updateData); err != nil {
		c.Status(500).JSON(err.Error())
	}
	user.FirstName = updateData.FirstName
	user.LastName = updateData.LastName

	database.Database.Db.Save(&user)
	responseUser := CreateResponseUser(user)
	c.Status(200).JSON(responseUser)
}
func DeleteUser (c *fiber.Ctx) {
	idStr := c.Params("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.Status(400).JSON("Please ensure that :id is an integer")
		return
	}
	var user models.User
	if err := findUser(id, &user); err != nil {
		c.Status(400).JSON(err.Error())
		return
	}
	if err :=database.Database.Db.Delete(&user).Error; err != nil {
		c.Status(404).JSON(err.Error())
	}
	c.Status(200).SendString("Successfully deleted user")
}