package routes

import (
	"errors"
	"strconv"

	"github.com/gofiber/fiber"
	"github.com/josh114/fiberapi/database"
	"github.com/josh114/fiberapi/models"
)

type Product struct {
	ID uint `json:"id"`
	Name string `json:"name"`
	SerialNumber string `json:"serial_number"`
}

func CreateResponseProduct(productModel models.Product) Product {
	return Product{ID: productModel.ID, Name: productModel.Name, SerialNumber: productModel.SerialNumber }
}

func CreateProduct (c *fiber.Ctx) {
	var product models.Product

	if err := c.BodyParser(&product); err != nil {
		c.Status(400).JSON(err.Error())
		return
	}
	database.Database.Db.Create(&product)

	responseProduct := CreateResponseProduct(product)
	c.Status(200).JSON(responseProduct)
}

func GetProducts (c *fiber.Ctx) {
	product := []models.Product{}
	database.Database.Db.Find(&product)
	resProducts := []Product{}

	for _, product := range product {
		resProduct := CreateResponseProduct(product)
		resProducts = append(resProducts, resProduct)
	}
	c.Status(200).JSON(resProducts)
}

func findProduct(id int, product *models.Product)error {
	database.Database.Db.Find(&product, "id = ?", id)
	if product.ID == 0 {
		return errors.New("product does not exist")
	}
	return nil
}

func GetProduct (c *fiber.Ctx) {
	idStr := c.Params("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.Status(400).JSON("Please ensure that :id is an integer")
		return
	}
	var product models.Product
	if err := findProduct(id, &product); err != nil {
		c.Status(400).JSON(err.Error())
		return
	}
	resProduct := CreateResponseProduct(product)
	c.Status(200).JSON(resProduct)
}
func UpdateProduct (c *fiber.Ctx) {
	idStr := c.Params("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.Status(400).JSON("Please ensure that :id is an integer")
		return
	}
	var product models.Product
	if err := findProduct(id, &product); err != nil {
		c.Status(400).JSON(err.Error())
		return
	}
	type UpdateProduct struct {
		Name string `json:"name"`
		SerialNumber string `json:"serial_number"`
	}
	var updateData UpdateProduct
	if err := c.BodyParser(&updateData); err != nil {
		c.Status(500).JSON(err.Error())
	}
	product.Name = updateData.Name
	product.SerialNumber = updateData.SerialNumber

	database.Database.Db.Save(&product)
	resProduct := CreateResponseProduct(product)
	c.Status(200).JSON(resProduct)
}
func DeleteProduct (c *fiber.Ctx) {
	idStr := c.Params("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		c.Status(400).JSON("Please ensure that :id is an integer")
		return
	}
	var product models.Product
	if err := findProduct(id, &product); err != nil {
		c.Status(400).JSON(err.Error())
		return
	}
	if err :=database.Database.Db.Delete(&product).Error; err != nil {
		c.Status(404).JSON(err.Error())
	}
	c.Status(200).SendString("Successfully deleted user")
}